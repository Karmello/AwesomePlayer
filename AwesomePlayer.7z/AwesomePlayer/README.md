# AwesomePlayer (college project)

Music player that provides most of the standard functionality like shuffle playing, muting, playlist editing, track searching, volume changing etc.
